<template>
  <div class="Erro">
    <img src="../../erro_imagem.jpg" class="imagem">
    <div class="texto">Ocorreu um Erro</div>
    <button @click="voltar">Voltar</button>
  </div>
</template>

<script>
export default {
  methods: {
    voltar() {
      this.$router.push('/');
    }
  }
}
</script>

<style scoped>
.Erro {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100vh;
  text-align: center;
  margin-left: 40%;
}
.imagem{
    width: 70vh;
}
.texto{
    font-size: xx-large;
    color: red;
    font-weight: bold;
}
button{
    background-color: #ffffff;
    color: #000000;
    border: none;
    padding: 5px 10px;
    border-radius: 5px;
    font-weight: bold;
    margin: 5px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    width: 100px;
    height: 50px;
}
</style>