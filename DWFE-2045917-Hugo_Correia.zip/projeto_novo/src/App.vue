<template>
  <div class="base" v-if="$route.name !== 'erro'">
    <header class="header">
      <div class="header-content">
        <button class="header-button" @click="toggleLoginForm">Login</button>
        <button class="header-button" @click="toggleRegisterForm">Registrar</button>
        <div class="login-form" v-show="showLoginForm">
          <input type="email" v-model="loginEmail" placeholder="Email">
          <input type="password" v-model="loginPassword" placeholder="Password">
          <button class="user-button" @click="login">Entrar</button>
        </div>
        <div class="register-form" v-show="showRegisterForm">
          <input type="email" v-model="registerEmail" placeholder="Email">
          <input type="password" v-model="registerPassword" placeholder="Password">
          <button class="user-button" @click="register">Registrar</button>
        </div>
      </div>
      <input type="text" v-model="pesquisa" class="search-bar" placeholder="Pesquise o Jogo Aqui">
      <div v-if="currentUser" class="user-email">{{ currentUser.email }}</div>
    </header>
    <div class="container">
      <div class="lista">
        <div v-for="jogo in jogosFiltrados" :key="jogo.id" >
          <div @click="adicionarAoCarrinho(jogo)">
            <div class="jogoItem">
              <img :src="jogo.thumbnail" class="thumbnailJogo">
              <span class="titulo">{{ jogo.title }}</span>
            </div>
          </div>
        </div>
      </div>
      <div class="carrinho">
        <h2 class="comprasTitulo">Lista de Compras</h2>
        <div class="barra"></div>
        <div v-for="jogo in carrinho" :key="jogo.id" class="jogoItemCarrinho" @click="removerDoCarrinho(jogo)">
          <img :src="jogo.thumbnail" class="thumbnailJogo">
          <span class="titulo">{{ jogo.title }}</span>
        </div>
      </div>
    </div>
  </div>
<RouterView/>
</template>

<script>
import axios from 'axios'
import firebase from 'firebase/app'
import 'firebase/auth'
import 'firebase/database'

export default {
  data() {
    return {
      jogos: [],
      genero: null,
      thumbnailJogo: null,
      descJogo: null,
      jogoSelec: null,
      carrinho: [],
      pesquisa: '',
      showLoginForm: false,
      showRegisterForm: false,
      loginEmail: '',
      loginPassword: '',
      registerUsername: '',
      registerEmail: '',
      registerPassword: '',
      currentUser: null
    }
  },
  computed: {
    jogosFiltrados() {
      if (this.pesquisa) {
        return this.jogos.filter(jogo =>
          jogo.title.toLowerCase().includes(this.pesquisa.toLowerCase())
        );
      }
      return this.jogos;
    }
  },
  methods: {
    fetchData() {
      axios.get('https://www.freetogame.com/api/games')
        .then(res => this.jogos = res.data)
        .catch(error => {
          this.$router.push({ name: 'Erro', params: { mensagemErro: 'Falha ao buscar dados dos jogos.' } });
        });
    },
    adicionarAoCarrinho(jogo) {
      const index = this.carrinho.findIndex(item => item.id === jogo.id);
      if (index === -1) {
        this.carrinho.push(jogo);
      }
      this.saveCarrinho();
    },
    removerDoCarrinho(jogo) {
      const index = this.carrinho.findIndex(item => item.id === jogo.id);
      if (index !== -1) {
        this.carrinho.splice(index, 1);
      }
      this.saveCarrinho();
    },
    toggleLoginForm() {
      this.showLoginForm = !this.showLoginForm;
      if (this.showLoginForm) {
        this.showRegisterForm = false;
      }
    },
    toggleRegisterForm() {
      this.showRegisterForm = !this.showRegisterForm;
      if (this.showRegisterForm) {
        this.showLoginForm = false;
      }
    },
    login() {
      const email = this.loginEmail;
      const password = this.loginPassword;

      firebase.auth().signInWithEmailAndPassword(email, password)
        .then((userCredential) => {
          this.currentUser = userCredential.user;
          this.loadCarrinho();
          console.log('Login bem sucedido');
        })
        .catch((error) => {
          console.error('Erro durante o login:', error);
          this.$router.push({ name: 'Erro', params: { mensagemErro: 'Erro durante o login: ' + error.message } });
        });
    },
    register() {
      const email = this.registerEmail;
      const password = this.registerPassword;

      firebase.auth().createUserWithEmailAndPassword(email, password)
        .then((userCredential) => {
          this.currentUser = userCredential.user;
          console.log('Registro bem sucedido');
        })
        .catch((error) => {
          console.error('Erro durante o registro:', error);
          this.$router.push({ name: 'Erro', params: { mensagemErro: 'Erro durante o registro: ' + error.message } });
        });
    },
    saveCarrinho() {
      if (this.currentUser) {
        firebase.database().ref(`/carrinhos/${this.currentUser.uid}`).set(this.carrinho);
      }
    },
    loadCarrinho() {
      if (this.currentUser) {
        firebase.database().ref(`/carrinhos/${this.currentUser.uid}`).once('value')
          .then(snapshot => {
            const carrinhoData = snapshot.val();
            this.carrinho = carrinhoData ? Object.values(carrinhoData) : [];
          })
          .catch(error => {
            console.error('Erro ao carregar o carrinho:', error);
            this.$router.push({ name: 'Erro', params: { mensagemErro: 'Erro ao carregar o carrinho: ' + error.message } });
          });
      } else {
        this.carrinho = [];
      }
    }
  },
  mounted() {
    this.fetchData();
    const firebaseConfig = {
      apiKey: "AIzaSyCATioYFwSQ6kAd0kq5sdCiWcLJ4fJc4rY",
      authDomain: "projetofe-56d3f.firebaseapp.com",
      projectId: "projetofe-56d3f",
      storageBucket: "projetofe-56d3f.appspot.com",
      messagingSenderId: "316019048290",
      appId: "1:316019048290:web:0ae3c576730e7e15f0363b",
      measurementId: "G-SJ4JGMBWHS"
    };
    if (!firebase.apps.length) {
      firebase.initializeApp(firebaseConfig);
    }

    firebase.auth().onAuthStateChanged((user) => {
      if (user) {
        this.currentUser = user;
        this.loadCarrinho();
      }
    });
  }
}
</script>

<style>
.base {
  display: flex;
  flex-direction: column;
  height: 100vh;
  margin-top: 20px;
}

.header {
  background-color: #60626b;
  padding: 10px;
  display: flex;
  justify-content: center;
  width: 100%;
  display: flex;
  justify-content: space-around;
}

.header-content {
  display: flex;
  align-items: center;
  gap: 20px;
}

.header-button {
  background-color: #ffffff;
  color: #000000;
  border: none;
  padding: 10px 20px;
  cursor: pointer;
  border-radius: 5px;
  font-weight: bold;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

.user-button {
  background-color: #ffffff;
  color: #000000;
  border: none;
  padding: 5px 10px;
  cursor: pointer;
  border-radius: 5px;
  font-weight: bold;
  margin: 5px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

.header-button:hover {
  background-color: #000000;
  color: white;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
  transition: transform 0.3s, box-shadow 0.3s;
}

.search-bar {
  padding: 10px;
  border-radius: 5px;
  border: 2px solid #60626b;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
  margin-left: 20px;
  width: 50%;
}

.container {
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 20px;
  color: #ffffff;
  font-family: Arial, Helvetica, sans-serif;
  min-width: 125vh;
}

.lista {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 20px;
  min-width: 70%;
  max-height: 100vh;
  overflow: scroll;
}

.carrinho {
  background-color: #1e1e1e;
  padding: 20px;
  border-radius: 8px;
  min-height: 100%;
  min-width: 30%;
  margin-left: 20px;
}

.jogoItem {
  background-color: #60626b;
  border-radius: 5px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
  transition: transform 0.3s, box-shadow 0.3s;
  width: 170px;
}

.jogoItem:hover {
  transform: translateY(-10px);
  box-shadow: 0 8px 16px rgba(0, 0, 0, 0.4);
}

.jogoItemCarrinho {
  background-color: #3a3e46;
  border-radius: 5px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
  margin-top: 10px;
  margin-bottom: 10px;
  padding: 10px;
  display: flex;
  align-items: center;
}

.comprasTitulo {
  font-weight: bold;
}

.barra {
  height: 2px;
  background-color: white;
}

.thumbnailJogo {
  width: 100%;
  height: 120px;
  object-fit: cover;
  border-bottom: 2px solid #171a21;
}

.titulo {
  display: block;
  padding: 10px;
  font-size: 16px;
  font-weight: bold;
  text-align: center;
  color: #ffffff;
}

.jogoItemCarrinho .thumbnailJogo {
  width: 50px;
  height: 50px;
  object-fit: cover;
  margin-right: 10px;
}

.jogoItem span {
  display: block;
  padding: 10px;
  font-size: 14px;
  text-align: center;
  color: #c7d5e0;
}

.jogoItem span:hover {
  color: #ffffff;
}

.user-email{
  color: white;
  font-weight: bold;
  font-size: large;
}
</style>